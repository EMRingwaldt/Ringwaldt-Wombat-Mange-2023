### Ringwaldt et al., (2023) Host, environment, and anthropogenic factors drive landscape dynamics of an environmentally transmitted pathogen: sarcoptic mange in the bare-nosed wombat.  
# Journal of Animal Ecology 
# R script used to recreate results for this manuscript 
##########################################################################################

#### 1 #### Logistical regression and SDM of images vs. mange 
#### 2 #### Bare-nosed wombat data set 
#### 3 #### SDM stack creation from data sources 
#### 4 #### Bare-nosed wombat SDM fine tuning hyperparameters
#### 5 #### Bare-nosed wombat ensemble SDM 
#### 6 #### Sarcoptes scabiei / sarcoptic mange SDM fine tuning 
#### 7 #### Sarcoptes scabiei / sarcoptic mange ensemble SDM 
#### Additional figure for the difference between SDMs 

#############################################################################
## 1   ## Logistical regression and SDM of images vs. mange 
##########################################################################
rm(list=ls()); options(scipen=999)
library(dplyr) # load libraries needed
libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet"); lapply(libs, require, character.only=T); ls("package:deepsdm"); 
installAll() #necessary when first installing 'sdm' package
# read in raw full dataset 
setwd('C:/') ##set to your folder
# load in datasets 
# all 2362 wombat presences obtained from camera trapping data have been through 1km2 grids and duplicates removed to create the below datasets 
dat1 <- read.csv("healthy_mangeonly_651.csv")#651 - 621 absences ('0', healthy wombats) + 30 presences ('1' mange certain)
dat2 <- read.csv("healthy_mangeboth_755.csv")#755 - 621 absences ('0', healthy wombats) + 134 presences  ('1' mange certain and uncertain ) 

########### LOGISTICAL REGRESSION ###################################### ###########
## binomial logistical regression on mange vs. no' images (per cameratrap)
## does the number of images mean more likely to see mange? 
library(tidyverse)
dat <- dat2 # choose one of the datasets called in above, then run the code below 
dat$Image_logs <- log10(dat$ImagesTotal+1)
hist(dat$Image_logs)
#
model <- glm(disease ~ 1 + Image_logs,family = binomial(link="logit"),data = dat)
summary(model)
drop1(model, test = "Chisq")
confint(model,level =0.95)
# create a plot with a best-fitting line
# generate a vector of Images that span those observed
x <- seq(from = min(dat$Image_logs), to = max(dat$Image_logs), length.out = 4)

# extract the model parameters from the GLM fit
beta.0 <- model$coefficients[1] # y-intercept
beta.1 <- model$coefficients[2] # slope

p <- beta.0 + beta.1 * x   # calculate the linear bit
p <- exp(p) / (1 + exp(p)) # calc the inverse-link to match the obs

# create a new data frame with the predicted values
df_fitted <- data_frame(Image_Total_log = x, prob_infected_mange = p)
glimpse(df_fitted)

ggplot(dat, aes(x = Image_logs, y =disease, color = disease)) +
  geom_point() +
  geom_line( # add the fitted line to the plot
    data = df_fitted, # where the data comes from
    aes(x = Image_Total_log, y = prob_infected_mange), # what to place on the x and y axes
    color = "red") + # color of the line
  xlab("Images Total of wombats") + ylab("mange (0 = no, 1 = yes)") +
  theme_bw()


### 
df_predict <- data.frame(
  Image_logs = seq(from = min(dat$Image_logs), to = max(dat$Image_logs), length.out = 4)
)

# make predictions and include the standard errors
#   values are for the linear component, not the response
model_fit <- predict(model, newdata = df_predict, type = "link", se.fit = TRUE)

# add the relevant values to the data frame
df_predict$fit_linear = model_fit$fit
df_predict$sem_linear = model_fit$se.fit

# perform the inverse link function
#   probability of success
df_predict$fit_response = exp(df_predict$fit_linear) / 
  (1.0 + exp(df_predict$fit_linear))
#   approx. 95%CI are mean +/- 1.96 standard errors
df_predict$low95_response = exp(df_predict$fit_linear - 1.96*df_predict$sem_linear) / 
  (1.0 + exp(df_predict$fit_linear - 1.96*df_predict$sem_linear))
df_predict$upp95_response = exp(df_predict$fit_linear + 1.96*df_predict$sem_linear) / 
  (1.0 + exp(df_predict$fit_linear + 1.96*df_predict$sem_linear))

# plot data from two data frames
ggplot() +
  geom_ribbon(data = df_predict, 
              aes(x = Image_logs, ymin = low95_response, ymax = upp95_response), fill = "grey85") +
  geom_line(data = df_predict, 
            aes(x = Image_logs, y = fit_response), color = "black") +
  geom_point(data = dat, 
             aes(x = Image_logs, y = jitter(disease, amount = 0.04), color = disease)) +
  labs(x = "Images per site (log transformmed)", y = "Probability of sarcoptic mange disease", color = "mange infection status") +
  scale_y_continuous(breaks = c(0,0.2, 0.4, 0.6, 0.8, 1)) +
  theme_bw()

############## create a raster layer for images, using the SDM layers created below ### 3 + 5 ###
wom.stack <- stack("C:/")# call in stack of raster used in SDM analysis  
womsuit <- raster("C:/") # add in BNW SDM suitability layer (this needs to be scaled)
spdf <- SpatialPointsDataFrame(coords = dat[,1:2], data = dat) # presence-absence spatial points dataframe
plot(spdf)
d <- spdf
crs(d) 
crs(d) <- NA
crs(d) <- CRS("+proj=longlat +datum=WGS84 +towgs84=0,0,0")
#e <- crop(d, extent(womsuit))
#ea <- extent(139, 155,-44, -23)
ext <- extent(womsuit)
r <- raster(ext, res=0.01)  
r <- rasterize(d, r, field="ImagesTotal")
plot(r)
names(r) <- c('Images');names(r)
#
womsuit<- stack(scale(womsuit, center = TRUE, scale = TRUE)) 
Images <- stack(scale(r, center = TRUE, scale = TRUE))
wom.stack <- stack(womsuit, Images, wom.stack)
plot(wom.stack)#
#create the training data
spdf <- SpatialPointsDataFrame(coords = dat[,1:2], data = dat);ps <- spdf[,4]  # presence-absence spatial points dataframe


d <- sdmData(f(disease)~f(Land.Use)+ f(Veg)+ AnMeanTemp+ TempAnnualRange+AnnualPrecip+PrecipSeason+     
               Dist.FW+ Top.Roughness + Wom.Suitability + Images, train=ps, 
             predictors=wom.stack)

#
d@species

################ Hyperparameters for the image SDM
##use parallel computing
library(doParallel)
detectCores()
cl <- makePSOCKcluster(8) 
registerDoParallel(cl)
#
sdmdata <- as.data.frame(d) ## there were Nas in the data, now 741 data points 

sdmdata <- sdmdata[,-1]#if there's an additional column called 'rID'
##NAs 
#A <- sdmdata[which(sdmdata$mange==0),] #610 so theres 11 NAs from enviro variables
#B <- sdmdata[which(sdmdata$mange==1),] # 131 so theres 3 NAs from enviro variables 
# together that adds to the 741 dataset sites in the manuscript
##
th=0.5 #setting the threshold for wombat pres/abs
sdmdata$disease <- ifelse(sdmdata$disease>th,"present","absent") #caret needs characters for the threshold
# below is for the Kfold 
library(caret)
control<-trainControl(## 10-fold CV
  method = "repeatedcv",
  number = 10,
  ## repeated 10 times
  repeats = 10,summaryFunction = twoClassSummary, ##twoClassSummary is for binomial classes. You need it to get ROC
  selectionFunction = "best", classProbs = T)     ## we're working classProbs
#
## no of predictors tried at each tree split. Set the upper bound to total number of predictors + 1
mtry <- c(1:10)
#
tunegrid <- expand.grid(.mtry = mtry) ## incrementally expand the number of predictors tried. 
#
rf_model = caret::train(disease~.,            
                        data=sdmdata, 
                        method="rf",
                        metric="ROC",
                        family=binomial,
                        tuneGrid = tunegrid,
                        trControl=control)
# ROC is measured form the error of the left out subsampling data  
rf_model #best mtry was 2
#
plot(rf_model)
##
glm_model = caret::train(disease~.,
                         data=sdmdata,
                         method="glm",
                         metric="ROC",
                         family=binomial, trControl=control)

glm_model
#plot(glm_model)
# 
gam_model = caret::train(disease~ .,
                         data=sdmdata,
                         method="gam",
                         distribution="bernoulli",
                         metric="ROC",
                         family=binomial, trControl=control)
#
gam_model
#
plot(gam_model)
### now create the model to run - rf, glm, and gam ensemble 
d <- sdmData(f(disease)~f(Land.Use)+ f(Veg)+ AnMeanTemp+ TempAnnualRange+AnnualPrecip+PrecipSeason+     
               Dist.FW+ Top.Roughness + Wom.Suitability + Images, train=ps, 
             predictors=wom.stack)

m1 <- sdm(disease~f(Land.Use)+ f(Veg)+ AnMeanTemp+ TempAnnualRange+AnnualPrecip+PrecipSeason+
            Dist.FW+ Top.Roughness + Wom.Suitability + Images, data=d,
          methods=c('rf', 'glm', 'gam'),
          modelSettings=list(
            rf=list(ntree=1000,maxnodes = NULL, mtry=2),#mtry 2, based on tuning 
            gam=list(method= 'GCV.Cp', select=FALSE)), 
          replication='cv',cv.folds=10, n=10)
#
m1 # Check model fitting process
getModelInfo(m1)
roc(m1)# plot the receiver-operator curve and show AUC
eval <- getEvaluation(m1,stat=c('TSS','AUC'),) # look at performance of different CV folds
#Figure for variable importance plots ##
vi <- getVarImp(m1, id=1:300, wtest='test.dep') # this calculates the importance of the variables by averaging all the models together
vi <- plot(vi, "AUC")
vi
# extract the data 

vidata <- vi[["data"]]
vidata <- as.data.frame(vidata)
vidata$variables <- c("Landuse", "Vegetation", "Annual Mean Temperature", "Temperature Annual Range", "Annual Precipitation", "Precipitation Seasonally (Co-efficient)", "Distance to Freshwater", "Topographic Roughness", "BNW Suitability", "Images per site")
vidata$variables <- as.factor(vidata$variables)
colnames(vidata) <- c("variables", "AUCtest", "lower", "upper")
write.csv(vidata, "MBsdm_imagesIncl.csv", row.names = FALSE)

viplot <-  ggplot(data=vidata, aes( x = AUCtest, y = reorder(variables, AUCtest))) + # df and axes
  geom_col(width = 0.5) +
  geom_errorbar(aes(
    xmin = lower,
    xmax = upper,
    width = 0.2, # width of error bars
  ))+
  labs(x = "AUC test", y = "Predictors") +
  theme_classic(base_size = 22)

viplot

#### Response curve ggplots ##
rcurve(m1)
resplot1 <- getResponseCurve(m1)


##########################################################################################################################
##########################################################################################################################
## 2   ## Bare-nosed wombat dataset creation 
###############################################################################################################
rm(list=ls()); options(scipen=999)
library(dplyr) # load libraries needed
libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet"); lapply(libs, require, character.only=T); ls("package:deepsdm"); 
installAll() #necessary when first installing 'sdm' package
setwd('C:/') ##set to your folder
# load in dataset
wompres <- read.csv("healthy_mangeboth_755.csv") # all camera trap wombat presences 755 - Note: all 2362 wombat presences obtained from camera trapping data have been through 1km2 grids and duplicates removed to create this dataset for convenience  
ALA <- read.csv("tas_wom_ALA.csv") # all ALA data (duplicates and anomolies removed) 1222
womabs <- read.csv("Wombat_Absences_225.csv") # all camera trap wombat absences (true absences, where camera ran for more than 78 days) 225 
## 
wompres <- wompres[c(1:2)] #just lat and lon of wombat presences

#####################################
####COMBINE WOMBAT AND ALA DATA
#####################################
tasgrid <- read.csv("tas_grid.csv") # Load a pre-defined map grid for Tas (~1km)
Wpres <-rbind(wompres, ALA) #
Wpres <- Wpres[!duplicated(Wpres[,c("Lon","Lat")]),]  #if there are any duplicates
# aggregate all sites by 0.01 arc degree 
n.p <- length(Wpres$Lon) # number of wombat observations
pres.rt <- presdist(tasgrid$Lon, tasgrid$Lat, Wpres$Lon, Wpres$Lat, dist.limit=0.1, prog.bar=T) #min dist is ~1km/ 0.01 arc degree
Wpres <- pres.rt[which(pres.rt$pres==T),] #1609 wombat presence 
Wpres <- Wpres[-c(3)]
colnames(Wpres)<-c("Lon","Lat")
#I want to remove any absence which is within ~1km of a presence 
n.p <- length(womabs$Lon)
abs.rt <- presdist(tasgrid$Lon, tasgrid$Lat, womabs$Lon, womabs$Lat, dist.limit=0.1, prog.bar=T)
womabs <- abs.rt[which(abs.rt$pres==T),] #185 'true' wombat absence 
colnames(womabs)<-c("Lon","Lat")
womabs <- anti_join(womabs, Wpres) #remove all wombat absences within a grid cell/site of a presence, final data is 138 true wombat absences 

####################################
####FINAL WOMBAT DATA SET 
####################################
## create a new dataframe with wombat presence and absence at either 0/1 
Wpres[,3] <- 1; colnames(Wpres) <- c("Lon","Lat", "Wombatpres")
womabs[,3]<- 0; colnames(womabs) <- c("Lon","Lat", "Wombatpres")
BNW <-rbind(Wpres, womabs) #1747 pres and abs for wombats
write.csv(BNW, "BNW_PRES_ABS.csv") 



#####################################################################################################################################
## 3   ## SDM stack creation from data sources ############
####################################################################################################################################

## Reclassifying land use and vegetation layers
### vegetation - Sourced from NVIS data https://www.environment.gov.au/land/native-vegetation/national-vegetation-information-system/data-products#mvg60
# rm(list=ls()); options(scipen=999)
# libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet", "rgdal", "sp"); lapply(libs, require, character.only=T); ls("package:deepsdm")
# #load in stack which has the correct projection 
# # need to reclassify into the vegetation classes 
# veg.reclass <- as.matrix(read.csv('C://veg_reclass21.csv'),colnames=FALSE); veg.reclass #load in veg.reclass csv file
# veg <- raster('w001001.adf') 
# plot(veg) #load in veg layer, 
# rc <- veg
# rc <- reclassify(veg, veg.reclass); rc #reclassify raster according the veg reclass formating
# #
# Aus.stack <- stack("C://aus.stack.gri") # Read pre-created stack of SDM raster layers of aus.stack which contains distance to freshwater, Elevation, and topographic roughness 
# rc2 <- projectRaster(rc,Aus.stack,method = 'ngb') #re-project raster according to stack (longlat) using nearest neighbour 
# veg <- focal(rc2,w=matrix(1,3,3),fun=modal, NAonly=T, na.rm=T ) #fill in holes caused by rivers/roads using the modal values around the NA
# veg <- mask(veg, Aus.stack$meanDiurnal) #mask the layer with clim layer to remove waterbodies and fix up coastline
# plot(veg)
# writeRaster(veg,paste0(data.fil.loc,'VegLayer.grd'), overwrite=TRUE)
# # Code - reclass	Category - reclass
# # 1	Rainforest and wet Eucalypt forest
# # 2	Forest and woodland 
# # 3	Shrubland
# # 4	Grassland
# # 5	Highly modified
# # NA

### land use - sourced from from CLUM - https://www.agriculture.gov.au/abares/aclump/land-use/catchment-scale-land-use-of-australia-update-december-2018
# rm(list=ls()); options(scipen=999)
# libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet", "rgdal", "sp"); lapply(libs, require, character.only=T); ls("package:deepsdm")
# landuse <- raster('w001001.adf') 
# lu.reclass <- as.matrix(read.csv('C:lu_reclass21V3.csv'),colnames=FALSE); lu.reclass #load in veg.reclass csv file
# rc <- reclassify(landuse, lu.reclass); rc #reclassify raster according the lu reclass formating
# # class      : RasterLayer 
# # dimensions : 76740, 80200, 6154548000  (nrow, ncol, ncell)
# # resolution : 50, 50  (x, y)
# # extent     : -1888000, 2122000, -4847000, -1010000  (xmin, xmax, ymin, ymax)
# # crs        : +proj=aea +lat_0=0 +lon_0=132 +lat_1=-18 +lat_2=-36 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs 
# # source     : r_tmp_2021-09-28_124901_7052_67298.grd 
# # names      : w001001 
# # values     : 1, 4  (min, max)
# plot(rc) #plot new raster to eyeball
# ##load in aus.stack 
# veglayer <- stack("C://VegLayer.gri") # Read pre-created stack of SDM raster layers (above)
# rc2 <- projectRaster(rc,veglayer,method = 'ngb') #re-project raster according to stack (longlat) using nearest neighbour 
# landuse <- focal(rc2,w=matrix(1,3,3),fun=modal, NAonly=T, na.rm=T ) #fill in holes caused by rivers/roads using the modal values around the NA
# landuse <- mask(landuse, Veglayer) #mask the layer to remove waterbodies and fix up coastline
# plot(landuse)
# #
# writeRaster(landuse,paste0(data.fil.loc,'LUlayer2.grd'), overwrite=TRUE)
# # Code - Reclass	Category - Reclass
# # 1	Least modified landscape -  i.e. Conservation/Reserves
# # 2	Moderately modified landscape - i.e. Modified Native areas or Plantation forests
# # 3 Highly modified landscapes - i.e.	Farming, Urban & Industrial/intensive use areas
# # N/A	Water & Roads
# 

# # Raster Stack Creation 
# rm(list=ls()); options(scipen=999)
# library(dplyr)
# libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet"); lapply(libs, require, character.only=T); ls("package:deepsdm"); 
# libs<-list('rgdal','raster')
# lapply(libs, require, character.only=T)
# #load in new landuse layer
# LU <- raster('LUlayer2.gri') #land use layer from above
# plot(LU)
# names(LU) <- c('Land.Use'); names(LU)
# #load in new vegetation layer 
# Veg <- raster('VegLayer.gri') #veg layer from above
# plot(Veg)
# names(Veg) <- c('Veg');names(Veg)
# ###load in climate layer stack created from Biodiversity & Climate Change Virtual Laboratory (BCCVL; bccvl.org.au)
# clim.stack <- stack("C://clim.stack.gri") # 
# names(clim.stack)
# removeCollinearity(clim.stack, multicollinearity.cutoff = 0.70, sample.points=F, nb.points = 5000, plot=T) 
# vifcor(clim.stack) #check the multicollinearity between them
# #remove bioclim layers which I dont need
# #drop the clim.stack layers which we dont need
# clim.stack <- dropLayer(clim.stack, c(2:6,8:11,13:14,16:19))
# names(clim.stack) <- c('AnMeanTemp','TempAnnualRange','AnnualPrecip','PrecipSeason')
# ## current aus.stack
# Aus.stack <- stack("C://aus.stack.gri") # Read pre-created stack of SDM raster layers University of Tasmania, sources in supplementary
# # Only keep- Elevation, Dist.FW, Top.Roughness 
# Aus.stack <- dropLayer(Aus.stack, c(1:8,10:11,13:15))
# names(Aus.stack)
# #
# scl.stack <- stack(clim.stack, Aus.stack) #put both the covariate rasters together to scale 
# scl.stack <- stack(scale(scl.stack, center = TRUE, scale = TRUE)) #scale the covariates
# plot(scl.stack)
# #
# wom.stack <- stack(LU, Veg, scl.stack) #create a scaled stack from above data layers
# #womunscaled.stack <- stack(LU, Veg, clim.stack, Aus.stack) #create a non-scaled stack 
# #data.fil.loc <- 'C://' #file save spatial data
# #writeRaster(womunscaled.stack,paste0(data.fil.loc,'womunscaled.stack.grd'), overwrite=TRUE) #Australia wide 
# plot(wom.stack) # Australia wide
# ###
# Tas2 <- extent(143.0,149.5, -43.75,-39.5)#crop the wom.stack to tas and islands
# wom.stack <- crop(wom.stack, Tas2)
# plot(wom.stack)
# data.fil.loc <- 'C://'
# writeRaster(wom.stack,paste0(data.fil.loc,'wom.stack.grd'), overwrite=TRUE) #Tasmanian wide scaled stack, ready for SDM
# vifcor(wom.stack) #check the multicollinearity between them
# ##


###################################################################################################
#################################################################################################
## 4   ## Bare-nosed wombat SDM fine tuning 
################################################################################################
rm(list=ls()); options(scipen=999)
library(dplyr)
libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet"); lapply(libs, require, character.only=T); ls("package:deepsdm"); 
installAll() #necessary when first installing 'sdm' package
#read in main dataframe 
BNW <- read.csv("BNW_PRES_ABS.csv",); BNW <- BNW[-c(1)]
wom.stack <- stack("wom.stack.gri") #Raster stack, factors and all scaled environmental variables (made from above)
#plot(wom.stack)
spdf <- SpatialPointsDataFrame(coords = BNW[,1:2], data = BNW);ps <- spdf[,3]  # presence-absence spatial points dataframe
#create the training data
d <- sdmData(f(Wombatpres)~f(Land.Use)+ f(Veg)+ AnMeanTemp+ TempAnnualRange+AnnualPrecip+PrecipSeason+     
               Dist.FW+ Top.Roughness, train=ps, 
             predictors=wom.stack)
#
d@species
##use parallel computing
library(doParallel)
detectCores()
cl <- makePSOCKcluster(8) 
registerDoParallel(cl)
#
sdmdata <- as.data.frame(d) 
sdmdata <- sdmdata[,-1]#if there's an additional column called 'rID'
th=0.5 #setting the threshold for wombat pres/abs
sdmdata$Wombatpres <- ifelse(sdmdata$Wombatpres>th,"present","absent") #caret needs characters for the threshold
# below is for the Kfold 
library(caret)
control<-trainControl(## 10-fold CV
  method = "repeatedcv",
  number = 10,
  ## repeated 10 times
  repeats = 10,summaryFunction = twoClassSummary, ##twoClassSummary is for binomial classes. You need it to get ROC
  selectionFunction = "best", classProbs = T)     ## we're working classProbs
## no of predictors tried at each tree split. Set the upperbound to total number of predictors + 1, up to double
mtry <- c(1:10)
#
tunegrid <- expand.grid(.mtry = mtry) ## incrementally expand the number of predictors tried. 
rf_model = caret::train(Wombatpres~.,            
                        data=sdmdata, 
                        method="rf",
                        metric="ROC",
                        family=binomial,
                        tuneGrid = tunegrid,
                        trControl=control)
# ROC is measured form the error of the left out sub sampling data  
rf_model #best mtry was 3
plot(rf_model)
# However, the training ROC on the SDM is high because of a major class imbalance and a lot of predictors (SDM output below). 
# So, it can fit the training data perfectly, but it's clearly overfit when checking against the test data. 
# It might suggest reducing mtry or tuning based on the test score. Reduce mtry to 1 (i.e. only fitting 'stumps' in the RF, also known as 'weak learners')
#
gam_model = caret::train(Wombatpres ~ .,
                         data=sdmdata,
                         method="gam",
                         distribution="bernoulli",
                         metric="ROC",
                         family=binomial, trControl=control)

gam_model

plot(gam_model)
#hyperparameters for GAM include using the unknown smoothing parameter estimation method (GCV.Cp ) 
#and extra penalties can be used by GAM (select= True). 

###################################################################################################
#################################################################################################
## 5   ## Bare-nosed wombat ensemble SDM - RF + GLM + GAM 
###############################################################################################
#reloading the packages as caret sometimes masks some
library(dplyr)
libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet"); lapply(libs, require, character.only=T); ls("package:deepsdm"); 
installAll() #necessary when first installing 'sdm' package
# spatial points 
spdf <- SpatialPointsDataFrame(coords = BNW[,1:2], data = BNW);ps <- spdf[,3]  # presence-absence spatial points data frame
#create the training data (no elevation)
d <- sdmData(f(Wombatpres)~f(Land.Use)+ f(Veg)+ AnMeanTemp+ TempAnnualRange+AnnualPrecip+PrecipSeason+     
               Dist.FW+ Top.Roughness, train=ps, 
             predictors=wom.stack)

### now create the ensemble model to run - rf, glm, and gam ensemble 
m1 <- sdm(Wombatpres~f(Land.Use)+ f(Veg)+ AnMeanTemp+ TempAnnualRange + AnnualPrecip + PrecipSeason +
            Dist.FW+ Top.Roughness, data=d,
          methods=c('rf', 'glm', 'gam'),
          modelSettings=list(
            rf=list(ntree=1000,maxnodes = NULL, mtry=1), #mtry at one to reduce over fitting.
            gam=list(method= 'GCV.Cp', select=TRUE)),
          replication='cv',cv.folds=10, n=10)
#
m1 # Check model fitting process, return AUC and TSS for each model (rf, glm, gam)
# there are 300 models, 100 for each model
roc(m1)# plot the receiver-operator curve and show AUC, shows training and test performance 
#
eval <- getEvaluation(m1,stat=c('TSS','AUC'),) # look at performance of different CV folds 
mean(eval$AUC); sd(eval$AUC) # the average AUC fit, and standard deviation 
mean(eval$TSS); sd(eval$TSS) # the average TSS fit, and standard deviation  

######################################################### 
#### variable importance 
#########################################################
vi <- getVarImp(m1, id=1:300, wtest='test.dep') #this calculates the importance of the variables by averaging all the 300 models together
vi <- plot(vi, "AUC", gg=T)
vidata <- vi[["data"]]# extract the data 
vidata <- as.data.frame(vidata)
vidata$variables <- c("Land use", "Vegetation", "Annual Mean Temperature", "Temperature Annual Range", "Annual Precipitation", "Precipitation Seasonally (Co-efficient)", "Distance to Freshwater", "Topographic Roughness")
vidata$variables <- as.factor(vidata$variables)
colnames(vidata) <- c("variables", "AUCtest", "lower", "upper")
write.csv(vidata, "VIwombat.csv", row.names = FALSE)

viplot <-  ggplot(data=vidata, aes( x = AUCtest, y = reorder(variables, AUCtest))) + # 
  geom_col(width = 0.5) +
  geom_errorbar(aes(
    xmin = lower,
    xmax = upper,
    width = 0.2, # width of error bars
  ))+
  labs(x = "AUC test", y = "Predictors") +
  theme_classic(base_size = 22)

viplot



######################################################### 
#### Response curve 
#########################################################
rcurve(m1, id=1:300, wtest='test.dep') #shows full response curve for all variables 
resplot1 <- getResponseCurve(m1)
## Annual mean precipitation is the most important predictor variable 
## Create scaled/ unscaled plot 
AP <- resplot1@response[["AnnualPrecip"]]
AP <- as.matrix(AP)#keep as matrix 
AP <- as.data.frame(AP)
AP$ModelMean <- rowMeans(AP[,2:301])
write.csv(AP, "AnnualPrecip.csv")
AP1 <- AP[c(1,302)]
plot(AP1)
#
AP <- ggplot(AP1, aes(AnnualPrecip, ModelMean))+ 
  geom_line(col="black", size=1)+
  ylim(0.5, 1) +
  labs(x = "Annual Precipitation-scaled", y = "Response") +
  theme_classic(base_size = 22)

###### Response curve ggplots ####

resplot <- ggplot(resplot1, aes(x=Value, y=Response))+
  facet_wrap(~variable, scales="free_x")+
  geom_line(aes(linetype=Background), size=1)+
  geom_ribbon(aes(ymin=lower, ymax=upper), linetype=1, alpha=0.2)+
  theme_classic()


######################################################### 
#### BNW Suitability for each model and ensemble SDM 
#########################################################
no.core <- 5
p1 <- predict(m1,newdata=wom.stack,mean=T,nc=no.core) # use RF, GLM, and GAM to create 3 suitability plots
p1; plot(p1) # examine fits of each model type across Tas 
## weight by AUC all models to create ensemble suitability
e1 <- ensemble(m1,newdata=wom.stack,setting=list(method='weighted',stat='AUC'),wtest='test.dep', nc=no.core) # can use AUC, COR or TSS for weights
e1; plot(e1); points(pres, pch=20, cex=.01); points(abs, pch=1)#; points(p.abs, pch=1) # plot the ensemble map, with presence-absence points

#save both the ensemble and the model predictions / suitability 
data.fil.loc <- 'C:/'
writeRaster(p1,paste0(data.fil.loc,'WombatSuitability_3models.grd'), overwrite=TRUE)

names(e1) <- c('Wom.Suitability');names(e1)
data.fil.loc <- 'C:'
writeRaster(e1,paste0(data.fil.loc,'WomSuitability_ensemble.grd'), overwrite=TRUE)


## get suitability for across Tasmania 
WomSuit <- raster('WomSuitability_ensemble.grd')
mod.grid<- as.data.frame(rasterToPoints(WomSuit, spatial = TRUE)) #e1 predicted sdm 
mg <- sum(mod.grid$Wom.Suitability)/73395 #cells across Tasmania
mg # mean
min(mod.grid$Wom.Suitability)#
max(mod.grid$Wom.Suitability) #
##


###################################################
##### TAS mainland, King, Furneaux group individual plots 
#################################################
library(rasterVis)
library(ggplot2)
#
gplot(e1, maxpixels = 5000000000000000) + geom_tile(aes(fill = value)) +
  facet_wrap(~ variable) +
  scale_fill_gradient2(
    low = "#F2F2F2",
    mid = "khaki2",
    high = "green4",
    midpoint = 0.5,
    space = "Lab",
    na.value = "white",
    limits = c(0,1), breaks = c(0,0.2, 0.4, 0.6,0.8, 1),
    guide = guide_colorbar(barwidth = 1, ticks = TRUE, ticks.colour = "black", raster = TRUE, barheight = 7, nbin = 100, frame.colour = "black", levels = 10, draw.ulim = TRUE, draw.llim = TRUE), 
    name = "Suitability",
    aesthetics = "fill"
  )+
  coord_equal()+ 
  theme_light()
# 
WomSuit <- stack("C://WomSuitability_ensemble.gri")
TasOnly <- extent(143.0,149.5, -43.75,-40.30)#crop the wom.stack to only tas mainland
KingOnly <- extent(143.6,144.5, -40.25,-39.5)#
FurnOnly <- extent(147.5,148.6, -40.65,-39.5)
#
p <- WomSuit
p[KingOnly]<- NA
p[FurnOnly]<- NA
plot(p)
#
tas.stack <- crop(p , TasOnly)
plot(tas.stack) #plot using code above
m.grid<- as.data.frame(rasterToPoints(tas.stack, spatial = TRUE)) #e1 predicted sdm 
m <- sum(m.grid$Wom.Suitability )/70044 #cells across Tasmania
m # 
min(m.grid$Wom.Suitability )
max(m.grid$Wom.Suitability ) 

#
KingOnly <- extent(143.6,144.5, -40.25,-39.5)#crop to KI only 
king.stack <- crop(WomSuit , KingOnly)
plot(king.stack) #plot using code above
kg.grid<- as.data.frame(rasterToPoints(king.stack, spatial = TRUE)) #e1 predicted sdm 
kg <- sum(kg.grid$Wom.Suitability )/1186 #cells across Tasmania
kg # 
min(kg.grid$Wom.Suitability )
max(kg.grid$Wom.Suitability ) 

#
FurnOnly <- extent(147.5,148.6, -40.65,-39.5)#crop to Furneaux group  only 
Furn.stack <- crop(WomSuit , FurnOnly)
plot(Furn.stack) #plot using code above 
f.grid<- as.data.frame(rasterToPoints(Furn.stack, spatial = TRUE)) #e1 predicted sdm 
f <- sum(f.grid$Wom.Suitability )/2165 #cells across Tasmania
f # 
min(f.grid$Wom.Suitability )#
max(f.grid$Wom.Suitability ) #


######IBRA REGIONS
#rm(list=ls()); options(scipen=999)
setwd('C://')
libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet"); lapply(libs, require, character.only=T); ls("package:deepsdm"); 
libs <- c("sdm","usdm","deepsdm", "maptools","beepr", "parallel","rgeos","caret",
          "ggplot2","e1071","randomForest",'earth','raster','rgdal','RStoolbox', 'beepr')
lapply(libs, require, character.only=T)
library(raster)
library(shapefiles)
library(rgdal)
library(sp)
library(rgeos)
#
### Overlay bioregions
d <- shapefile("C:/IBRA7_subregions_states.shp") #https://www.environment.gov.au/fed/catalog/search/resource/downloadData.page?uuid=%7B1273FBE2-F266-4F3F-895D-C1E45D77CAF5%7D
#plot(d)
crs(d) 
crs(d) <- NA
crs(d) <- CRS("+proj=longlat +datum=WGS84 +towgs84=0,0,0")
e <- crop(d, extent(womunscaled.stack))
#ea <- extent(139, 155,-44, -23)
ext <- extent(e)
r <- raster(ext, res=0.01)  
r <- rasterize(e, r, field=1)
plot(r)
#
add.ibra <- function(d) {
  IBRA <- e # Load Tasmanian Interim Bioregionalisation of Australia polygons
  IBRA <- crop(IBRA, extent(womunscaled.stack))
  pts<-data.frame(x=d$x,y=d$y); pts[which(is.na(pts$x)),]<-c(0,0)
  coordinates(pts)<-~x+y; proj4string(pts)<-proj4string(IBRA) # geog points
  plot(IBRA,main="Tasmania IBRA Regions",asp=1.2); points(pts, pch=20, col='grey')
  d$IBRA <- over(pts,IBRA) # overlay IBRA region 
  return(d)
}

ovrlay <- add.ibra(mod.grid) # overlay on IBRA regionalisation
ovrlay <- as.matrix(ovrlay)
ovrlay <- as.data.frame(ovrlay)
ovrlay$Wom.Suitability <- as.numeric(ovrlay$Wom.Suitability)
##############

#IBRA region KIN01 suitability
IBRA.selectKIN01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="KIN01"),c(1:3,7)] 
KIN01<- sum(IBRA.selectKIN01$Wom.Suitability)/4503
KIN01 # 
min(IBRA.selectKIN01$Wom.Suitability)#0.5
max(IBRA.selectKIN01$Wom.Suitability) #1

#IBRA region FUR02 suitability
IBRA.selectFUR02 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="FUR02"),c(1:3,7)]  
FUR02 <- sum(IBRA.selectFUR02$Wom.Suitability)/5128
FUR02 #0.8991687
min(IBRA.selectFUR02$Wom.Suitability)#0.2642405
max(IBRA.selectFUR02$Wom.Suitability) #0.9999105

#IBRA region TNM01 suitability
IBRA.selectTNM01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TNM01"),c(1:3,7)]  
TNM01 <- sum(IBRA.selectTNM01$Wom.Suitability)/4500
TNM01 #
min(IBRA.selectTNM01$Wom.Suitability)#
max(IBRA.selectTNM01$Wom.Suitability) #

#IBRA region 4 suitability
IBRA.selectTNS01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TNS01"),c(1:3,7)]  
TNS01 <- sum(IBRA.selectTNS01$Wom.Suitability)/6654
TNS01 #
min(IBRA.selectTNS01$Wom.Suitability)#
max(IBRA.selectTNS01$Wom.Suitability) #

#IBRA region TCH01 suitability
IBRA.selectTCH01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TCH01"),c(1:3,7)]  
TCH01 <- sum(IBRA.selectTCH01$Wom.Suitability)/7824
TCH01 #
min(IBRA.selectTCH01$Wom.Suitability)#
max(IBRA.selectTCH01$Wom.Suitability) #

#IBRA region TWE01 suitability
IBRA.selectTWE01<- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TWE01"),c(1:3,7)]  
TWE01<- sum(IBRA.selectTWE01$Wom.Suitability)/16369
TWE01 #
min(IBRA.selectTWE01$Wom.Suitability)#
max(IBRA.selectTWE01$Wom.Suitability) #

#IBRA region TSR01 suitability
IBRA.selectTSR01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TSR01"),c(1:3,7)]  
TSR01 <- sum(IBRA.selectTSR01$Wom.Suitability)/8192
TSR01 #
min(IBRA.selectTSR01$Wom.Suitability)#
max(IBRA.selectTSR01$Wom.Suitability) #

#IBRA region BEL01 suitability
IBRA.selectBEL01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="BEL01"),c(1:3,7)]  
BEL01 <- sum(IBRA.selectBEL01$Wom.Suitability)/7075
BEL01 #
min(IBRA.selectBEL01$Wom.Suitability)#
max(IBRA.selectBEL01$Wom.Suitability) #

#IBRA region TSE01 suitability
IBRA.selectTSE01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TSE01"),c(1:3,7)]  
TSE01 <- sum(IBRA.selectTSE01$Wom.Suitability)/12268
TSE01 #0.9657855
min(IBRA.selectTSE01$Wom.Suitability)#
max(IBRA.selectTSE01$Wom.Suitability) #0.9998963


ibra.no.na <-rbind(KIN01,FUR02,TNM01, TNS01, TCH01, TWE01, TSR01, BEL01,TSE01 )
Full<- rbind(IBRA.selectKIN01, IBRA.selectFUR02, IBRA.selectTNM01, IBRA.selectTNS01, IBRA.selectTCH01, IBRA.selectTWE01, IBRA.selectTSR01, IBRA.selectBEL01, IBRA.selectTSE01)

Full <- data.frame(Full)

library(dplyr) #data wrangling tool
library(tidyverse) # manipulation and plotting data frames

df_sum <- Full %>% group_by(IBRA.SUB_CODE_7) %>%
  summarise(n=n(),mean_c = mean(Wom.Suitability), median_c = median(Wom.Suitability), min_c = min(Wom.Suitability), max_c = max(Wom.Suitability),
            s_c = sd(Wom.Suitability), se_c = s_c/ sqrt(n))

df_sum
df_sum$IBRA.SUB_CODE_7 <- as.factor(df_sum$IBRA.SUB_CODE_7)

ggplot(df_sum, aes(x = IBRA.SUB_CODE_7, y = mean_c, color= IBRA.SUB_CODE_7,)) + # df and axes
  geom_point() +
  geom_errorbar(aes(
    ymin = mean_c - se_c,
    ymax = mean_c + se_c,
    width = 0.5, # width of error bars
  ))+
  labs(x = "IBRA Regions", y = "Wombat Suitability 0-1") +
  theme_bw()

write.csv(df_sum, "IBRA_WOMSUIT.csv")




########################
#############################################################################################################################################
## 6  #### Sarcoptes scabiei / sarcoptic mange SDM fine tuning (code for both mange certain OR mange uncertain and certain) ####
############################################################################################################################################
rm(list=ls()); options(scipen=999)
library(dplyr) # load libraries needed
libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet"); lapply(libs, require, character.only=T); ls("package:deepsdm"); 
installAll() #necessary when first installing 'sdm' package
# read in raw full dataset 
setwd('C:/') ##set to your folder
# load in datasets 
dat1 <- read.csv("healthy_mangeonly_651.csv")#651 - 621 absences ('0', healthy wombats) + 30 presences ('1' mange certain)
dat2 <- read.csv("healthy_mangeboth_755.csv")#755 - 621 absences ('0', healthy wombats) + 134 presences  ('1' mange certain and uncertain ) 

### the code below can be used to run both S. scabiei SDMs, however only the manuscript included SDM is used below 
## chose one of the above to run 
dat <- dat2 # both mange certain and uncertain 
#dat <- dat1 # only mange certain 
#
dat <- dat[c(1:2,4)] 
pres<- dat[which(dat$disease==1),] #134 sites
abs<- dat[which(dat$disease==0),] #621 sites

###################################################
### ADD WOMBAT SUITABILITY ENSEMBLE TO RASTER STACK
#################################################
wom.stack <- stack("wom.stack.grd")# 
womsuit <- raster('WomSuitability_ensemble.grd')
#
womsuit<- stack(scale(womsuit, center = TRUE, scale = TRUE)) 
wom.stack <- stack(womsuit, wom.stack)
plot(wom.stack)#
#


#####################################
## FINE TUNING 
####################################
##use paraller computing
library(doParallel)
detectCores()
cl <- makePSOCKcluster(8) 
registerDoParallel(cl)
#
sdmdata <- as.data.frame(d) ## there were Nas in the data, now 741 data points (mange certain and uncertain)
#glimpse(sdmdata)
sdmdata <- sdmdata[,-1]#if there's an additional column called 'rID'
th=0.5 #setting the threshold 
sdmdata$MangeBoth1 <- ifelse(sdmdata$MangeBoth1>th,"present","absent") #caret needs characters for the threshold
# below is for the Kfold 
library(caret)
control<-trainControl(## 10-fold CV
  method = "repeatedcv",
  number = 10,
  ## repeated 10 times
  repeats = 10,summaryFunction = twoClassSummary, ##twoClassSummary is for binomial classes. You need it to get ROC
  selectionFunction = "best", classProbs = T)     ## we're working classProbs
#
mtry <- c(1:10)
#
tunegrid <- expand.grid(.mtry = mtry) ## incrementally expand the number of predictors tried. 
#
rf_model = caret::train(MangeBoth1~.,            
                        data=sdmdata, 
                        method="rf",
                        metric="ROC",
                        family=binomial,
                        tuneGrid = tunegrid,
                        trControl=control)
# ROC is measured form the error of the left out subsampling data  
rf_model #best mtry was 2
#
plot(rf_model)
##
glm_model = caret::train(MangeBoth1~.,
                         data=sdmdata,
                         method="glm",
                         metric="ROC",
                         family=binomial, trControl=control)
#
glm_model
#
plot(glm_model)
#
gam_model = caret::train(MangeBoth1~ .,
                         data=sdmdata,
                         method="gam",
                         distribution="bernoulli",
                         metric="ROC",
                         family=binomial, trControl=control)

gam_model
#
plot(gam_model)
#hyperparameters for GAM were the same for each: using the unknown smoothing parameter estimation method (GCV.Cp) and no extra penalties can be used by GAM (select = False). For mange certain SDM the optimum RF mtry was three predictor trees (mtry = 3),





######################################################
## 7 Sarcoptes scabiei / sarcoptic mange SDM  #### 
# ##########################################
############ RF + GLM + GAM SDM ##########
#reloading the packages as caret sometimes masks some
library(dplyr)
libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet"); lapply(libs, require, character.only=T); ls("package:deepsdm"); 
installAll() #necessary when first installing 'sdm' package
spdf <- SpatialPointsDataFrame(coords = dat[,1:2], data = dat);ps <- spdf[,3]  # presence-absence spatial points dataframe
#create the training data
d <- sdmData(f(MangeBoth1)~f(Land.Use)+ f(Veg)+ AnMeanTemp+ TempAnnualRange+AnnualPrecip+PrecipSeason+     
               Dist.FW+ Top.Roughness + Wom.Suitability, train=ps, 
             predictors=wom.stack)
#
d@species
### now create the model to run - rf, glm, and gam ensemble 
m1 <- sdm(MangeBoth1~f(Land.Use)+ f(Veg)+ AnMeanTemp+ TempAnnualRange+AnnualPrecip+PrecipSeason+
            Dist.FW+ Top.Roughness + Wom.Suitability, data=d,
          methods=c('rf', 'glm', 'gam'),
          modelSettings=list(
            rf=list(ntree=1000,maxnodes = NULL, mtry=2),#mtry 2, based on tuning 
            gam=list(method= 'GCV.Cp', select=FALSE)), 
          replication='cv',cv.folds=10, n=10)

#
m1 # Check model fitting process
getModelInfo(m1)
roc(m1)# plot the receiver-operator curve and show AUC
eval <- getEvaluation(m1,stat=c('TSS','AUC'),) # look at performance of different CV folds
##

######################################################### 
#### variable importance 
#########################################################
vi <- getVarImp(m1, id=1:300, wtest='test.dep') # this calculates the importance of the variables by averaging all the models together
vidata <- vi[["data"]]
vidata <- as.data.frame(vidata)
vidata$variables <- c("Landuse", "Vegetation", "Annual Mean Temperature", "Temperature Annual Range", "Annual Precipitation", "Precipitation Seasonally (Co-efficient)", "Distance to Freshwater", "Topographic Roughness", "BNW Suitability")
vidata$variables <- as.factor(vidata$variables)
matrix <- as.data.frame(matrix)
colnames(matrix) <- c("Predictors", "AUCtest", "lower", "upper")
write.csv(matrix, "VIuncertain.csv", row.names = FALSE)
vidata <- read.csv("VIuncertain.csv")

viplot <-  ggplot(data=vidata, aes( x = AUCtest, y = reorder(Predictors, AUCtest))) + # df and axes
  geom_col(width = 0.5) +
  geom_errorbar(aes(
    xmin = lower,
    xmax = upper,
    width = 0.2, # width of error bars
  ))+
  xlim(0,0.3)+
  labs(x = "AUC", y = "Predictors") +
  theme_classic(base_size = 22)

viplot

######################################################### 
#### Response curve 
#########################################################
rcurve(m1)
resplot1 <- getResponseCurve(m1)
setwd("C:/Users/eliser0/Dropbox/PhD/Wombat Chapter/RData/Results_20_10_21/VariableResponseUncertainmange")
#
WS <- resplot1@response[["Wom.Suitability"]]
WS <- as.matrix(WS)#keep as matrix 
WS <- as.data.frame(WS)
WS$ModelMean <- rowMeans(WS[,2:301])
write.csv(WS, "Wom.Suitability.csv")
WS1 <- WS[c(1,302)]
plot(WS1)
#
WS <- ggplot(WS1, aes(Wom.Suitability, ModelMean))+ 
  geom_line(col="black", size=1)+
  ylim(0.0, 0.3) +
  labs(x = "BNW-scaled", y = "AUC Response") +
  theme_classic(base_size = 22)


###### Response curve ggplots ####
resplot <- ggplot(resplot1, aes(x=Value, y=Response))+
  facet_wrap(~variable, scales="free_x")+
  geom_line(aes(linetype=Background), size=1)+
  geom_ribbon(aes(ymin=lower, ymax=upper), linetype=1, alpha=0.2)+
  theme_classic()




######################################################### 
#### S. scabiei Suitability for each model and ensemble SDM 
#########################################################
no.core <- 5
p1 <- predict(m1,newdata=wom.stack,mean=T,nc=no.core)
p1; plot(p1) # examine fits of each model type

e1 <- ensemble(m1,newdata=wom.stack,setting=list(method='weighted',stat='AUC'),wtest='test.dep', nc=no.core) # can use AUC, COR or TSS for weights, output ensemble image to a file (various formats possible)
e1; plot(e1); points(pres, pch=20, cex=.01); points(abs, pch=1)#; points(p.abs, pch=1) # plot the ensemble map, with presence-absence points


### plot 
library(rasterVis)
library(ggplot2)
#
gplot(e1, maxpixels = 500000000000) + geom_tile(aes(fill = value)) +
  facet_wrap(~ variable) +
  scale_fill_gradient2(
    low = "#F2F2F2",
    mid = "tomato3",
    high = "black",
    midpoint = 0.5,
    space = "Lab",
    na.value = "white",
    limits = c(0,1), breaks = c(0,0.2, 0.4, 0.6,0.8, 1),
    guide = guide_colorbar(barwidth = 1, ticks = TRUE, ticks.colour = "black", raster = TRUE, barheight = 7, nbin = 100, frame.colour = "black", levels = 10, draw.ulim = TRUE, draw.llim = TRUE), 
    name = "Suitability",
    aesthetics = "fill"
  )+
  coord_equal()+ 
  theme_light()
# "green4"khaki2

##########################################################
########CREATING Mange SUITABILITY RASTER LAYER ###########
############################################################
names(e1) <- c('MangeUncertain.Suitability');names(e1)
data.fil.loc <- 'C://'
writeRaster(e1,paste0(data.fil.loc,'MangeUncertainSuitability_ensemble.grd'), overwrite=TRUE)

data.fil.loc <- 'C://'
writeRaster(p1,paste0(data.fil.loc,'MangeUncertainSuitability_3models.grd'), overwrite=TRUE)

###
MUSuit <- raster('MangeUncertainSuitability_ensemble.grd') 
plot(MUSuit)

#################################################
#####################################
## get suitability for across Tasmania 
plot(MUSuit)
mod.grid<- as.data.frame(rasterToPoints(MUSuit, spatial = TRUE)) #e1 predicted sdm 
mg <- sum(mod.grid$MangeUncertain.Suitability)/73395 #cells across Tasmania
mg # mean
min(mod.grid$MangeUncertain.Suitability)#
max(mod.grid$MangeUncertain.Suitability) #


######IBRA REGIONS
#rm(list=ls()); options(scipen=999)
setwd('C://')
libs <- c("raster","sdm","virtualspecies","usdm","deepsdm","leaflet"); lapply(libs, require, character.only=T); ls("package:deepsdm"); 
libs <- c("sdm","usdm","deepsdm", "maptools","beepr", "parallel","rgeos","caret",
          "ggplot2","e1071","randomForest",'earth','raster','rgdal','RStoolbox', 'beepr')
lapply(libs, require, character.only=T)
library(raster)
library(shapefiles)
library(rgdal)
library(sp)
library(rgeos)
#
### Overlay bioregions
d <- shapefile("IBRA7_subregions_states.shp")#https://www.environment.gov.au/fed/catalog/search/resource/downloadData.page?uuid=%7B1273FBE2-F266-4F3F-895D-C1E45D77CAF5%7D
#plot(d)
crs(d) 
crs(d) <- NA
crs(d) <- CRS("+proj=longlat +datum=WGS84 +towgs84=0,0,0")
e <- crop(d, extent(womunscaled.stack))
#ea <- extent(139, 155,-44, -23)
ext <- extent(e)
r <- raster(ext, res=0.01)  
r <- rasterize(e, r, field=1)
plot(r)
#
add.ibra <- function(d) {
  IBRA <- e # Load Tasmanian Interim Bioregionalisation of Australia polygons
  IBRA <- crop(IBRA, extent(womunscaled.stack))
  pts<-data.frame(x=d$x,y=d$y); pts[which(is.na(pts$x)),]<-c(0,0)
  coordinates(pts)<-~x+y; proj4string(pts)<-proj4string(IBRA) # geog points
  plot(IBRA,main="Tasmania IBRA Regions",asp=1.2); points(pts, pch=20, col='grey')
  d$IBRA <- over(pts,IBRA) # overlay IBRA region for spatial analysis
  return(d)
}

ovrlay <- add.ibra(mod.grid) # overlay IBRA regionalisation
ovrlay <- as.matrix(ovrlay)
ovrlay <- as.data.frame(ovrlay)
ovrlay$MangeUncertain.Suitability <- as.numeric(ovrlay$MangeUncertain.Suitability)
##############
##
#IBRA region KIN01 suitability
IBRA.selectKIN01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="KIN01"),c(1:3,7)] 
KIN01<- sum(IBRA.selectKIN01$MangeUncertain.Suitability)/4503
KIN01 # 
min(IBRA.selectKIN01$MangeUncertain.Suitability)#
max(IBRA.selectKIN01$MangeUncertain.Suitability) #

#IBRA region FUR02 suitability
IBRA.selectFUR02 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="FUR02"),c(1:3,7)]  
FUR02 <- sum(IBRA.selectFUR02$MangeUncertain.Suitability)/5128
FUR02 #
min(IBRA.selectFUR02$MangeUncertain.Suitability)#
max(IBRA.selectFUR02$MangeUncertain.Suitability) #

#IBRA region TNM01 suitability
IBRA.selectTNM01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TNM01"),c(1:3,7)]  
TNM01 <- sum(IBRA.selectTNM01$MangeUncertain.Suitability)/4500
TNM01 #
min(IBRA.selectTNM01$MangeUncertain.Suitability)#
max(IBRA.selectTNM01$MangeUncertain.Suitability) #

#IBRA region 4 suitability
IBRA.selectTNS01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TNS01"),c(1:3,7)]  
TNS01 <- sum(IBRA.selectTNS01$MangeUncertain.Suitability)/6654
TNS01 #
min(IBRA.selectTNS01$MangeUncertain.Suitability)#
max(IBRA.selectTNS01$MangeUncertain.Suitability) #

#IBRA region TCH01 suitability
IBRA.selectTCH01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TCH01"),c(1:3,7)]  
TCH01 <- sum(IBRA.selectTCH01$MangeUncertain.Suitability)/7824
TCH01 #
min(IBRA.selectTCH01$MangeUncertain.Suitability)#
max(IBRA.selectTCH01$MangeUncertain.Suitability) #

#IBRA region TWE01 suitability
IBRA.selectTWE01<- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TWE01"),c(1:3,7)]  
TWE01<- sum(IBRA.selectTWE01$MangeUncertain.Suitability)/16369
TWE01 #
min(IBRA.selectTWE01$MangeUncertain.Suitability)#
max(IBRA.selectTWE01$MangeUncertain.Suitability) #

#IBRA region TSR01 suitability
IBRA.selectTSR01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TSR01"),c(1:3,7)]  
TSR01 <- sum(IBRA.selectTSR01$MangeUncertain.Suitability)/8192
TSR01 #
min(IBRA.selectTSR01$MangeUncertain.Suitability)#
max(IBRA.selectTSR01$MangeUncertain.Suitability) #

#IBRA region BEL01 suitability
IBRA.selectBEL01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="BEL01"),c(1:3,7)]  
BEL01 <- sum(IBRA.selectBEL01$MangeUncertain.Suitability)/7075
BEL01 #
min(IBRA.selectBEL01$MangeUncertain.Suitability)#
max(IBRA.selectBEL01$MangeUncertain.Suitability) #

#IBRA region TSE01 suitability
IBRA.selectTSE01 <- ovrlay[which(ovrlay$IBRA.SUB_CODE_7=="TSE01"),c(1:3,7)]  
TSE01 <- sum(IBRA.selectTSE01$MangeUncertain.Suitability)/12268
TSE01 #
min(IBRA.selectTSE01$MangeUncertain.Suitability)#
max(IBRA.selectTSE01$MangeUncertain.Suitability) #


ibra.no.na <-rbind(KIN01,FUR02,TNM01, TNS01, TCH01, TWE01, TSR01, BEL01,TSE01 )
Full<- rbind(IBRA.selectKIN01, IBRA.selectFUR02, IBRA.selectTNM01, IBRA.selectTNS01, IBRA.selectTCH01, IBRA.selectTWE01, IBRA.selectTSR01, IBRA.selectBEL01, IBRA.selectTSE01)

Full <- data.frame(Full)

library(dplyr) #data wrangling tool
library(tidyverse) # manipulation and plotting data frames

df_sum <- Full %>% group_by(IBRA.SUB_CODE_7) %>%
  summarise(n=n(),mean_c = mean(MangeUncertain.Suitability), median_c = median(MangeUncertain.Suitability), min_c = min(MangeUncertain.Suitability), max_c = max(MangeUncertain.Suitability),
            s_c = sd(MangeUncertain.Suitability), se_c = s_c/ sqrt(n))

df_sum
df_sum$IBRA.SUB_CODE_7 <- as.factor(df_sum$IBRA.SUB_CODE_7)
#df_sum$IBRA <- 1:9

ggplot(df_sum, aes(x = IBRA.SUB_CODE_7, y = mean_c, color= IBRA.SUB_CODE_7,)) + # df and axes
  geom_point() +
  geom_errorbar(aes(
    ymin = mean_c - se_c,
    ymax = mean_c + se_c,
    width = 0.5, # width of error bars
  ))+
  labs(x = "IBRA Regions", y = "mange Suitability 0-1") +
  theme_bw()


write.csv(df_sum, "IBRA_UncertainSuit.csv")

#################################################################################
##### Additional figure for the difference between SDMs 
##################################################################################
library(rasterVis)
library(ggrepel)
e1a <- raster("C://WomSuitability_ensemble.grd")
#e2a <- raster("C://MangeCertainSuitability_ensemble.grd")
e2b <- raster("C://MangeUncertainSuitability_ensemble.grd")
plot(e2b)
#e1a <- (-e1a)
#e2a <- (-e2a) 
e2b <- (-e2b)
e <- e1a+e2b
e[e==0] <- NA
plot(e,main="Difference in Habitat suitability ")

#
Fig <- gplot(e, maxpixels = 500000000000) + geom_tile(aes(fill = value)) +
  facet_wrap(~ variable) +
  scale_fill_gradient2(
    low = "black",
    mid = "grey31",
    high = "grey90",
    midpoint = 0.4,
    space = "Lab",
    na.value = "white",
    limits = c(0,1), breaks = c(0,0.2, 0.4, 0.6,0.8, 1),
    guide = guide_colorbar(reverse= FALSE, barwidth = 1, ticks = TRUE, ticks.colour = "black", raster = TRUE, barheight = 7, nbin = 100, frame.colour = "black", levels = 10, draw.ulim = TRUE, draw.llim = TRUE), 
    name = "Difference between",
    aesthetics = "fill"
  )+
  coord_equal()+ 
  theme_light()


#lat and long of all points which are talked about in the discussion 
coordinates_df <- data.frame(
  lon = c(145.9400, 148.0222, 148.0650, 147.4230, 143.9371, 148.0527, 145.6046691, 146.936207),
  lat = c(-41.6800, -40.7836, -42.6451, -41.7743, -39.8753, -39.9836, -42.2421868,-42.649386),
  label = c("Cradle Mountain", "Cape Portland", "Maria Island", "Northern Midlands", "King Island", "Flinders Island", "Tasmanian West", "Tasmanian South East")
)

coordinates_df


Fig1 <- (Fig +
           geom_point(data = coordinates_df %>% filter(label != "Maria Island" & label != "King Island"& label != "Northern Midlands" & label != "Flinders Island"& label != "Tasmanian West"& label != "Tasmanian South East"), aes(x = lon, y = lat), size = 4, shape = 1, color = "red", fill = NA) +
           # annotate("segment", x = 148.0650, y = -42.8, xend = 148.0650, yend = -42.75,
           #                       arrow = arrow(length = unit(0.3, "cm"), type = "closed"), color = "red", size = 0.0) +
           geom_text_repel(data=coordinates_df, aes(x=lon, y=lat, label=label), color="black", size=3.25,
                           nudge_x = c(-1.50, -0.05, 0.20, 1.35, 0.60, -0.80, -0.90, 1.15),
                           nudge_y = c(0,   0.125, -0.15, -0.00, -0.00, 0.00, 0.00, -0.7)))

#
Fig1
